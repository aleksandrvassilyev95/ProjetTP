<?php

class bugManager {
    
    function add() {
        
    }
    
    function list() {
        
      
    }
    
    function show() {
        
    }
} 

