<?php

$DB_HOST = "localhost";
$DB_NAME = "bug";
$DB_LOGIN = "root";
$DB_PASSWROD = "";

?>